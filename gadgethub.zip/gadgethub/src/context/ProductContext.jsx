import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { initialProducts } from '../data/products';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { STORAGE_KEYS } from '../utils/storageKeys';
import { generateId } from '../utils/helpers';

export const ProductContext = createContext(null);

const MAX_COMPARE = 4;

const seedNotifications = (products) =>
  products
    .filter((p) => p.originalPrice && p.originalPrice > p.price)
    .slice(0, 5)
    .map((p) => ({
      id: generateId(),
      productId: p.id,
      productName: p.name,
      oldPrice: p.originalPrice,
      newPrice: p.price,
      message: `Price drop on ${p.name}! Now ${p.price} (was ${p.originalPrice})`,
      read: false,
      createdAt: new Date().toISOString(),
    }));

export function ProductProvider({ children }) {
  const [products, setProducts] = useLocalStorage(
    STORAGE_KEYS.products,
    initialProducts
  );
  const [compareList, setCompareList] = useLocalStorage(
    STORAGE_KEYS.compare,
    []
  );
  const [recentlyViewed, setRecentlyViewed] = useLocalStorage(
    STORAGE_KEYS.recentlyViewed,
    []
  );
  const [recentSearches, setRecentSearches] = useLocalStorage(
    STORAGE_KEYS.recentSearches,
    []
  );
  const [notifications, setNotifications] = useLocalStorage(
    STORAGE_KEYS.notifications,
    []
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!products?.length) {
      setProducts(initialProducts);
    }
    setLoading(false);
  }, [products, setProducts]);

  useEffect(() => {
    if (notifications.length === 0 && products.length > 0) {
      setNotifications(seedNotifications(products));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const getProductById = useCallback(
    (id) => products.find((p) => p.id === Number(id)),
    [products]
  );

  const addToCompare = useCallback(
    (productId) => {
      setCompareList((prev) => {
        if (prev.includes(productId)) return prev;
        if (prev.length >= MAX_COMPARE) return prev;
        return [...prev, productId];
      });
    },
    [setCompareList]
  );

  const removeFromCompare = useCallback(
    (productId) => {
      setCompareList((prev) => prev.filter((id) => id !== productId));
    },
    [setCompareList]
  );

  const clearCompare = useCallback(() => setCompareList([]), [setCompareList]);

  const addRecentSearch = useCallback(
    (query) => {
      const q = query.trim();
      if (!q) return;
      setRecentSearches((prev) => {
        const filtered = prev.filter((s) => s.toLowerCase() !== q.toLowerCase());
        return [q, ...filtered].slice(0, 8);
      });
    },
    [setRecentSearches]
  );

  const markNotificationRead = useCallback(
    (id) => {
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
    },
    [setNotifications]
  );

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, [setNotifications]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const compareProducts = useMemo(
    () => compareList.map((id) => getProductById(id)).filter(Boolean),
    [compareList, getProductById]
  );

  const value = useMemo(
    () => ({
      products,
      loading,
      getProductById,
      compareList,
      compareProducts,
      addToCompare,
      removeFromCompare,
      clearCompare,
      recentlyViewed,
      setRecentlyViewed,
      recentSearches,
      addRecentSearch,
      notifications,
      markNotificationRead,
      markAllNotificationsRead,
      unreadCount,
    }),
    [
      products,
      loading,
      getProductById,
      compareList,
      compareProducts,
      addToCompare,
      removeFromCompare,
      clearCompare,
      recentlyViewed,
      setRecentlyViewed,
      recentSearches,
      addRecentSearch,
      notifications,
      markNotificationRead,
      markAllNotificationsRead,
      unreadCount,
    ]
  );

  return (
    <ProductContext.Provider value={value}>{children}</ProductContext.Provider>
  );
}

export function useProductContext() {
  const ctx = useContext(ProductContext);
  if (!ctx) throw new Error('useProductContext must be used within ProductProvider');
  return ctx;
}
