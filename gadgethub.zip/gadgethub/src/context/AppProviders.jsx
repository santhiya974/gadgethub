import { ThemeProvider } from './ThemeContext';
import { ToastProvider } from './ToastContext';
import { ProductProvider } from './ProductContext';
import { CartProvider } from './CartContext';
import { WishlistProvider } from './WishlistContext';

export function AppProviders({ children }) {
  return (
    <ThemeProvider>
      <ToastProvider>
        <ProductProvider>
          <CartProvider>
            <WishlistProvider>{children}</WishlistProvider>
          </CartProvider>
        </ProductProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
