import {
  createContext,
  useContext,
  useCallback,
  useMemo,
} from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { STORAGE_KEYS } from '../utils/storageKeys';
import { ProductContext } from './ProductContext';

const WishlistContext = createContext(null);

export function WishlistProvider({ children }) {
  const [wishlist, setWishlist] = useLocalStorage(STORAGE_KEYS.wishlist, []);
  const { getProductById } = useContext(ProductContext);

  const addToWishlist = useCallback(
    (productId) => {
      setWishlist((prev) =>
        prev.includes(productId) ? prev : [...prev, productId]
      );
    },
    [setWishlist]
  );

  const removeFromWishlist = useCallback(
    (productId) => {
      setWishlist((prev) => prev.filter((id) => id !== productId));
    },
    [setWishlist]
  );

  const toggleWishlist = useCallback(
    (productId) => {
      setWishlist((prev) =>
        prev.includes(productId)
          ? prev.filter((id) => id !== productId)
          : [...prev, productId]
      );
    },
    [setWishlist]
  );

  const wishlistProducts = useMemo(
    () => wishlist.map((id) => getProductById(id)).filter(Boolean),
    [wishlist, getProductById]
  );

  const value = useMemo(
    () => ({
      wishlist,
      wishlistProducts,
      wishlistCount: wishlist.length,
      addToWishlist,
      removeFromWishlist,
      toggleWishlist,
      isInWishlist: (productId) => wishlist.includes(productId),
    }),
    [
      wishlist,
      wishlistProducts,
      addToWishlist,
      removeFromWishlist,
      toggleWishlist,
    ]
  );

  return (
    <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>
  );
}

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error('useWishlist must be used within WishlistProvider');
  return ctx;
}
