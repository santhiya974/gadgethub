import {
  createContext,
  useContext,
  useReducer,
  useEffect,
  useCallback,
  useMemo,
} from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { STORAGE_KEYS } from '../utils/storageKeys';
import { ProductContext } from './ProductContext';

const CartContext = createContext(null);

const cartReducer = (state, action) => {
  switch (action.type) {
    case 'SET':
      return action.payload;
    case 'ADD': {
      const existing = state.find((i) => i.productId === action.payload.productId);
      if (existing) {
        return state.map((i) =>
          i.productId === action.payload.productId
            ? { ...i, quantity: i.quantity + (action.payload.quantity || 1) }
            : i
        );
      }
      return [
        ...state,
        {
          productId: action.payload.productId,
          quantity: action.payload.quantity || 1,
        },
      ];
    }
    case 'UPDATE':
      return state.map((i) =>
        i.productId === action.payload.productId
          ? { ...i, quantity: action.payload.quantity }
          : i
      );
    case 'REMOVE':
      return state.filter((i) => i.productId !== action.payload);
    case 'CLEAR':
      return [];
    default:
      return state;
  }
};

export function CartProvider({ children }) {
  const [storedCart, setStoredCart] = useLocalStorage(STORAGE_KEYS.cart, []);
  const [cart, dispatch] = useReducer(cartReducer, storedCart);
  const { getProductById } = useContext(ProductContext);

  useEffect(() => {
    setStoredCart(cart);
  }, [cart, setStoredCart]);

  const addToCart = useCallback((productId, quantity = 1) => {
    dispatch({ type: 'ADD', payload: { productId, quantity } });
  }, []);

  const updateQuantity = useCallback((productId, quantity) => {
    if (quantity < 1) {
      dispatch({ type: 'REMOVE', payload: productId });
    } else {
      dispatch({ type: 'UPDATE', payload: { productId, quantity } });
    }
  }, []);

  const removeFromCart = useCallback((productId) => {
    dispatch({ type: 'REMOVE', payload: productId });
  }, []);

  const clearCart = useCallback(() => {
    dispatch({ type: 'CLEAR' });
  }, []);

  const cartItems = useMemo(
    () =>
      cart
        .map((item) => {
          const product = getProductById(item.productId);
          if (!product) return null;
          return { ...item, product };
        })
        .filter(Boolean),
    [cart, getProductById]
  );

  const cartCount = useMemo(
    () => cart.reduce((sum, i) => sum + i.quantity, 0),
    [cart]
  );

  const subtotal = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
    [cartItems]
  );

  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  const value = useMemo(
    () => ({
      cart,
      cartItems,
      cartCount,
      subtotal,
      tax,
      total,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
      isInCart: (productId) => cart.some((i) => i.productId === productId),
    }),
    [
      cart,
      cartItems,
      cartCount,
      subtotal,
      tax,
      total,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
    ]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
