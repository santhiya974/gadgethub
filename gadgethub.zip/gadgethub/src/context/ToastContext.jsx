import {
  createContext,
  useContext,
  useReducer,
  useCallback,
  useMemo,
} from 'react';

const ToastContext = createContext(null);

const initialState = { toasts: [] };

function toastReducer(state, action) {
  switch (action.type) {
    case 'ADD':
      return {
        toasts: [
          ...state.toasts,
          { id: action.payload.id, message: action.payload.message, type: action.payload.type },
        ],
      };
    case 'REMOVE':
      return { toasts: state.toasts.filter((t) => t.id !== action.payload) };
    default:
      return state;
  }
}

export function ToastProvider({ children }) {
  const [state, dispatch] = useReducer(toastReducer, initialState);

  const showToast = useCallback((message, type = 'success') => {
    const id = Date.now();
    dispatch({ type: 'ADD', payload: { id, message, type } });
    setTimeout(() => dispatch({ type: 'REMOVE', payload: id }), 3200);
  }, []);

  const removeToast = useCallback((id) => {
    dispatch({ type: 'REMOVE', payload: id });
  }, []);

  const value = useMemo(
    () => ({ toasts: state.toasts, showToast, removeToast }),
    [state.toasts, showToast, removeToast]
  );

  return (
    <ToastContext.Provider value={value}>{children}</ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
