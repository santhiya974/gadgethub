export const STORAGE_KEYS = {
  products: 'gadgethub_products',
  cart: 'gadgethub_cart',
  wishlist: 'gadgethub_wishlist',
  compare: 'gadgethub_compare',
  notifications: 'gadgethub_notifications',
  recentlyViewed: 'gadgethub_recentlyViewed',
  recentSearches: 'gadgethub_recentSearches',
  theme: 'gadgethub_theme',
};
