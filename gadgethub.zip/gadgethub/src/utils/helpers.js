export const formatPrice = (price) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(price);

export const clamp = (value, min, max) =>
  Math.min(Math.max(value, min), max);

export const generateId = () =>
  `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

export const sortProducts = (products, sortBy) => {
  const sorted = [...products];
  switch (sortBy) {
    case 'price-low':
      return sorted.sort((a, b) => a.price - b.price);
    case 'price-high':
      return sorted.sort((a, b) => b.price - a.price);
    case 'rating':
      return sorted.sort((a, b) => b.rating - a.rating);
    case 'name':
      return sorted.sort((a, b) => a.name.localeCompare(b.name));
    default:
      return sorted;
  }
};

export const filterProducts = (products, filters) => {
  const { category, minPrice, maxPrice, search } = filters;
  return products.filter((p) => {
    const matchCategory =
      !category || category === 'All' || p.category === category;
    const matchMin = minPrice === '' || p.price >= Number(minPrice);
    const matchMax = maxPrice === '' || p.price <= Number(maxPrice);
    const query = (search || '').toLowerCase().trim();
    const matchSearch =
      !query ||
      p.name.toLowerCase().includes(query) ||
      p.brand.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query);
    return matchCategory && matchMin && matchMax && matchSearch;
  });
};
