/**
 * Simple rule-based recommendation engine.
 */
export function getRecommendations({
  products,
  cartIds,
  wishlistIds,
  recentlyViewedIds,
  limit = 8,
}) {
  const scores = new Map();

  const bump = (id, weight) => {
    scores.set(id, (scores.get(id) || 0) + weight);
  };

  const cartProducts = cartIds
    .map((id) => products.find((p) => p.id === id))
    .filter(Boolean);
  const viewedProducts = recentlyViewedIds
    .map((id) => products.find((p) => p.id === id))
    .filter(Boolean);
  const wishlistProducts = wishlistIds
    .map((id) => products.find((p) => p.id === id))
    .filter(Boolean);

  const interestCategories = new Set([
    ...cartProducts.map((p) => p.category),
    ...viewedProducts.map((p) => p.category),
    ...wishlistProducts.map((p) => p.category),
  ]);

  const excludeIds = new Set([
    ...cartIds,
    ...wishlistIds,
    ...recentlyViewedIds.slice(0, 3),
  ]);

  products.forEach((p) => {
    if (excludeIds.has(p.id)) return;
    if (interestCategories.has(p.category)) bump(p.id, 3);
    if (p.featured) bump(p.id, 1);
    bump(p.id, p.rating * 0.5);
    if (p.originalPrice && p.originalPrice > p.price) bump(p.id, 1.5);
  });

  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([id]) => products.find((p) => p.id === id))
    .filter(Boolean);
}
