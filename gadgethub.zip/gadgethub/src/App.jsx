import Navbar from './components/Navbar/Navbar';
import Footer from './components/Footer/Footer';
import ToastContainer from './components/Toast/Toast';
import AppRoutes from './routes/AppRoutes';

export default function App() {
  return (
    <div className="app-layout">
      <Navbar />
      <main className="main-content">
        <AppRoutes />
      </main>
      <Footer />
      <ToastContainer />
    </div>
  );
}
