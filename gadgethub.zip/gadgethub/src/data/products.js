/**
 * Seed product catalog for GadgetHub.
 * Initial load is persisted to localStorage via ProductContext.
 */
export const initialProducts = [
  {
    id: 1,
    name: 'iPhone 16 Pro',
    category: 'Mobile',
    price: 999,
    originalPrice: 1099,
    rating: 4.8,
    brand: 'Apple',
    description:
      'The iPhone 16 Pro features a titanium design, A18 Pro chip, and an advanced camera system with 5x optical zoom.',
    specifications: {
      display: '6.3 inch Super Retina XDR',
      ram: '8GB',
      storage: '256GB',
      battery: '3350mAh',
      processor: 'A18 Pro',
      camera: '48MP Main + 12MP Ultra Wide',
    },
    image:
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 2,
    name: 'Samsung Galaxy S24 Ultra',
    category: 'Mobile',
    price: 1199,
    originalPrice: 1299,
    rating: 4.7,
    brand: 'Samsung',
    description:
      'Galaxy AI powers this flagship with S Pen, 200MP camera, and stunning 6.8-inch display.',
    specifications: {
      display: '6.8 inch Dynamic AMOLED 2X',
      ram: '12GB',
      storage: '512GB',
      battery: '5000mAh',
      processor: 'Snapdragon 8 Gen 3',
      camera: '200MP Main + 50MP Periscope',
    },
    image:
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 3,
    name: 'MacBook Pro 14"',
    category: 'Laptop',
    price: 1999,
    originalPrice: 2199,
    rating: 4.9,
    brand: 'Apple',
    description:
      'M3 Pro chip delivers exceptional performance for professionals. Liquid Retina XDR display.',
    specifications: {
      display: '14.2 inch Liquid Retina XDR',
      ram: '18GB',
      storage: '512GB SSD',
      battery: 'Up to 18 hours',
      processor: 'Apple M3 Pro',
      weight: '1.55 kg',
    },
    image:
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 4,
    name: 'Dell XPS 15',
    category: 'Laptop',
    price: 1499,
    rating: 4.6,
    brand: 'Dell',
    description:
      'Premium Windows laptop with InfinityEdge display and Intel Core Ultra processors.',
    specifications: {
      display: '15.6 inch OLED 3.5K',
      ram: '16GB',
      storage: '1TB SSD',
      battery: '86Wh',
      processor: 'Intel Core Ultra 7',
      weight: '1.92 kg',
    },
    image:
      'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 5,
    name: 'Sony WH-1000XM5',
    category: 'Audio',
    price: 349,
    originalPrice: 399,
    rating: 4.8,
    brand: 'Sony',
    description:
      'Industry-leading noise canceling with exceptional sound quality and 30-hour battery.',
    specifications: {
      type: 'Over-ear Wireless',
      battery: '30 hours',
      connectivity: 'Bluetooth 5.3',
      weight: '250g',
      features: 'Multipoint, Speak-to-Chat',
    },
    image:
      'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 6,
    name: 'AirPods Pro 2',
    category: 'Audio',
    price: 249,
    rating: 4.7,
    brand: 'Apple',
    description:
      'Active Noise Cancellation, Adaptive Audio, and USB-C charging case.',
    specifications: {
      type: 'In-ear Wireless',
      battery: '6 hours (30 with case)',
      connectivity: 'Bluetooth 5.3',
      features: 'Spatial Audio, H2 chip',
    },
    image:
      'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 7,
    name: 'Apple Watch Ultra 2',
    category: 'Wearable',
    price: 799,
    rating: 4.8,
    brand: 'Apple',
    description:
      'The most rugged and capable Apple Watch for outdoor adventures and extreme sports.',
    specifications: {
      display: '49mm Always-On Retina',
      battery: '36 hours',
      waterResistance: '100m',
      material: 'Titanium',
      gps: 'Dual-frequency GPS',
    },
    image:
      'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 8,
    name: 'Samsung Galaxy Watch 6',
    category: 'Wearable',
    price: 299,
    originalPrice: 349,
    rating: 4.5,
    brand: 'Samsung',
    description:
      'Advanced health monitoring, sleep coaching, and seamless Galaxy ecosystem integration.',
    specifications: {
      display: '44mm Super AMOLED',
      battery: '40 hours',
      waterResistance: '5ATM + IP68',
      sensors: 'BioActive Sensor',
      compatibility: 'Android & iOS',
    },
    image:
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 9,
    name: 'iPad Pro 13"',
    category: 'Tablet',
    price: 1299,
    rating: 4.8,
    brand: 'Apple',
    description:
      'M4 chip, stunning Ultra Retina XDR display, and Apple Pencil Pro support.',
    specifications: {
      display: '13 inch Ultra Retina XDR',
      ram: '8GB',
      storage: '256GB',
      battery: 'Up to 10 hours',
      processor: 'Apple M4',
      connectivity: 'Wi-Fi 6E',
    },
    image:
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 10,
    name: 'PlayStation 5 Slim',
    category: 'Gaming',
    price: 499,
    originalPrice: 549,
    rating: 4.9,
    brand: 'Sony',
    description:
      'Next-gen gaming with lightning-fast load times, ray tracing, and 4K gaming.',
    specifications: {
      storage: '1TB SSD',
      resolution: 'Up to 4K 120fps',
      rayTracing: 'Yes',
      controller: 'DualSense included',
      dimensions: '358 x 216 x 80 mm',
    },
    image:
      'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600&h=600&fit=crop',
    ],
    featured: true,
  },
  {
    id: 11,
    name: 'Nintendo Switch OLED',
    category: 'Gaming',
    price: 349,
    rating: 4.7,
    brand: 'Nintendo',
    description:
      '7-inch OLED screen, enhanced audio, and wide adjustable stand for tabletop mode.',
    specifications: {
      display: '7 inch OLED',
      storage: '64GB',
      battery: '4.5–9 hours',
      modes: 'TV, Tabletop, Handheld',
      weight: '420g',
    },
    image:
      'https://images.unsplash.com/photo-1578303512597-81e6cced1e23?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1578303512597-81e6cced1e23?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 12,
    name: 'DJI Mini 4 Pro',
    category: 'Camera',
    price: 759,
    rating: 4.6,
    brand: 'DJI',
    description:
      'Compact drone with 4K HDR video, omnidirectional obstacle sensing, and 34-min flight time.',
    specifications: {
      camera: '4K/60fps HDR',
      flightTime: '34 minutes',
      range: '20 km O4 transmission',
      weight: '249g',
      sensors: 'Omnidirectional obstacle',
    },
    image:
      'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 13,
    name: 'GoPro Hero 12',
    category: 'Camera',
    price: 399,
    originalPrice: 449,
    rating: 4.5,
    brand: 'GoPro',
    description:
      'Best-in-class image stabilization, HDR video, and waterproof to 33ft without a case.',
    specifications: {
      video: '5.3K60, 4K120',
      stabilization: 'HyperSmooth 6.0',
      waterproof: '33ft (10m)',
      battery: 'Enduro battery included',
      weight: '153g',
    },
    image:
      'https://images.unsplash.com/photo-1526170375885-4d8ecf77bcea?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1526170375885-4d8ecf77bcea?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 14,
    name: 'Amazon Echo Show 15',
    category: 'Smart Home',
    price: 279,
    rating: 4.4,
    brand: 'Amazon',
    description:
      '15.6-inch smart display for home organization, Alexa, and Fire TV built-in.',
    specifications: {
      display: '15.6 inch Full HD',
      resolution: '1920 x 1080',
      assistant: 'Alexa',
      connectivity: 'Wi-Fi, Bluetooth',
      features: 'Fire TV, Widgets',
    },
    image:
      'https://images.unsplash.com/photo-1558082037-0d3bf09e6e88?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1558082037-0d3bf09e6e88?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 15,
    name: 'Google Nest Hub Max',
    category: 'Smart Home',
    price: 229,
    originalPrice: 279,
    rating: 4.3,
    brand: 'Google',
    description:
      '10-inch smart display with Google Assistant, Nest Cam, and gesture controls.',
    specifications: {
      display: '10 inch HD',
      camera: 'Nest Cam built-in',
      assistant: 'Google Assistant',
      audio: 'Stereo speakers',
      features: 'Face Match, Quick Gestures',
    },
    image:
      'https://images.unsplash.com/photo-1558002032-1055907df827?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1558002032-1055907df827?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
  {
    id: 16,
    name: 'Logitech MX Master 3S',
    category: 'Accessories',
    price: 99,
    rating: 4.7,
    brand: 'Logitech',
    description:
      'Ergonomic wireless mouse with 8K DPI tracking, quiet clicks, and multi-device connectivity.',
    specifications: {
      dpi: '8000',
      battery: '70 days',
      connectivity: 'Bluetooth, USB receiver',
      buttons: '7 programmable',
      weight: '141g',
    },
    image:
      'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&h=600&fit=crop',
    ],
    featured: false,
  },
];

export const categories = [
  'All',
  'Mobile',
  'Laptop',
  'Audio',
  'Wearable',
  'Tablet',
  'Gaming',
  'Camera',
  'Smart Home',
  'Accessories',
];
