import { useContext, useMemo, useCallback } from 'react';
import { ProductContext } from '../context/ProductContext';
import { filterProducts, sortProducts } from '../utils/helpers';

/**
 * Custom hook for product queries and filtering.
 */
export function useProducts(filters = {}) {
  const { products, getProductById, loading } = useContext(ProductContext);

  const filtered = useMemo(
    () => sortProducts(filterProducts(products, filters), filters.sortBy),
    [products, filters]
  );

  const featured = useMemo(
    () => products.filter((p) => p.featured),
    [products]
  );

  const byCategory = useCallback(
    (category) =>
      category === 'All'
        ? products
        : products.filter((p) => p.category === category),
    [products]
  );

  const related = useCallback(
    (productId, limit = 4) => {
      const product = getProductById(productId);
      if (!product) return [];
      return products
        .filter((p) => p.id !== productId && p.category === product.category)
        .slice(0, limit);
    },
    [products, getProductById]
  );

  return {
    products,
    filtered,
    featured,
    loading,
    getProductById,
    byCategory,
    related,
  };
}
