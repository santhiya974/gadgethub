import { useContext, useCallback } from 'react';
import { ProductContext } from '../context/ProductContext';

const MAX_ITEMS = 12;

/**
 * Track and retrieve recently viewed products from localStorage.
 */
export function useRecentlyViewed() {
  const { recentlyViewed, setRecentlyViewed, getProductById } =
    useContext(ProductContext);

  const addRecentlyViewed = useCallback(
    (productId) => {
      setRecentlyViewed((prev) => {
        const filtered = prev.filter((id) => id !== productId);
        return [productId, ...filtered].slice(0, MAX_ITEMS);
      });
    },
    [setRecentlyViewed]
  );

  const recentlyViewedProducts = recentlyViewed
    .map((id) => getProductById(id))
    .filter(Boolean);

  return {
    recentlyViewedIds: recentlyViewed,
    recentlyViewedProducts,
    addRecentlyViewed,
  };
}
