import { memo } from 'react';

function ProductCardSkeleton() {
  return (
    <div className="product-card" aria-hidden="true">
      <div className="skeleton" style={{ aspectRatio: '1' }} />
      <div style={{ padding: '1rem' }}>
        <div className="skeleton" style={{ height: 12, width: '40%', marginBottom: 8 }} />
        <div className="skeleton" style={{ height: 18, width: '80%', marginBottom: 8 }} />
        <div className="skeleton" style={{ height: 14, width: '30%', marginBottom: 12 }} />
        <div className="skeleton" style={{ height: 24, width: '50%' }} />
      </div>
    </div>
  );
}

export default memo(ProductCardSkeleton);
