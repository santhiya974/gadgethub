import { memo } from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <h4 style={{ color: 'var(--accent)', fontSize: '1.25rem' }}>GadgetHub</h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '0.5rem' }}>
              Your destination for cutting-edge tech gadgets. Quality products, smart recommendations.
            </p>
          </div>
          <div>
            <h4>Shop</h4>
            <Link to="/products">All Products</Link>
            <Link to="/recommendations">AI Recommendations</Link>
            <Link to="/wishlist">Wishlist</Link>
            <Link to="/compare">Compare</Link>
          </div>
          <div>
            <h4>Account</h4>
            <Link to="/cart">Cart</Link>
            <Link to="/notifications">Notifications</Link>
            <Link to="/recently-viewed">Recently Viewed</Link>
          </div>
          <div>
            <h4>Company</h4>
            <Link to="/about">About Us</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
        <div className="footer-bottom">
          © {new Date().getFullYear()} GadgetHub. Built with React & Local Storage.
        </div>
      </div>
    </footer>
  );
}

export default memo(Footer);
