import { memo, useState, useCallback } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useProductContext } from '../../context/ProductContext';
import { useTheme } from '../../context/ThemeContext';
import SearchBar from '../SearchBar/SearchBar';

const navItems = [
  { to: '/', label: 'Home', end: true },
  { to: '/products', label: 'Products' },
  { to: '/recommendations', label: 'AI Picks' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
];

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { cartCount } = useCart();
  const { wishlistCount } = useWishlist();
  const { compareList, unreadCount } = useProductContext();
  const { toggleTheme, isDark } = useTheme();

  const closeMenu = useCallback(() => setMenuOpen(false), []);

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="navbar-logo" onClick={closeMenu}>
          Gadget<span>Hub</span>
        </Link>

        <nav className="navbar-nav" aria-label="Main navigation">
          {navItems.map(({ to, label, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `nav-link ${isActive ? 'active' : ''}`
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>

        <SearchBar className="navbar-search-desktop" />

        <div className="navbar-actions">
          <button
            type="button"
            className="nav-icon-btn"
            onClick={toggleTheme}
            aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            title="Toggle theme"
          >
            {isDark ? '☀️' : '🌙'}
          </button>
          <Link to="/notifications" className="nav-icon-btn" title="Notifications">
            🔔
            {unreadCount > 0 && (
              <span className="badge" style={{ position: 'absolute', top: 4, right: 4 }}>
                {unreadCount}
              </span>
            )}
          </Link>
          <Link to="/wishlist" className="nav-icon-btn" title="Wishlist">
            ❤️
            {wishlistCount > 0 && (
              <span className="badge" style={{ position: 'absolute', top: 4, right: 4 }}>
                {wishlistCount}
              </span>
            )}
          </Link>
          <Link to="/compare" className="nav-icon-btn" title="Compare">
            ⚖️
            {compareList.length > 0 && (
              <span className="badge" style={{ position: 'absolute', top: 4, right: 4 }}>
                {compareList.length}
              </span>
            )}
          </Link>
          <Link to="/cart" className="nav-icon-btn" title="Cart">
            🛒
            {cartCount > 0 && (
              <span className="badge" style={{ position: 'absolute', top: 4, right: 4 }}>
                {cartCount}
              </span>
            )}
          </Link>
          <button
            type="button"
            className="nav-icon-btn menu-toggle"
            onClick={() => setMenuOpen((o) => !o)}
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
          >
            ☰
          </button>
        </div>
      </div>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        <SearchBar />
        {navItems.map(({ to, label, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            onClick={closeMenu}
          >
            {label}
          </NavLink>
        ))}
        <NavLink to="/recently-viewed" className="nav-link" onClick={closeMenu}>
          Recently Viewed
        </NavLink>
      </div>
    </header>
  );
}

export default memo(Navbar);
