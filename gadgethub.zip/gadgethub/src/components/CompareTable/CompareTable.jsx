import { memo, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { formatPrice } from '../../utils/helpers';

function CompareTable({ products, onRemove }) {
  const specKeys = useMemo(() => {
    const keys = new Set();
    products.forEach((p) => {
      Object.keys(p.specifications || {}).forEach((k) => keys.add(k));
    });
    return [...keys];
  }, [products]);

  const isDifferent = (key) => {
    const values = products.map((p) => p.specifications?.[key] ?? '—');
    return new Set(values).size > 1;
  };

  if (!products.length) {
    return (
      <div className="empty-state">
        <h3>No products to compare</h3>
        <p>Add up to 4 gadgets from product pages to compare specs side by side.</p>
        <Link to="/products" className="btn btn-primary">
          Browse Products
        </Link>
      </div>
    );
  }

  return (
    <div className="compare-table-wrapper">
      <table className="compare-table">
        <thead>
          <tr>
            <th>Product</th>
            {products.map((p) => (
              <th key={p.id} className="compare-product-header">
                <img src={p.image} alt="" />
                <Link to={`/products/${p.id}`}>{p.name}</Link>
                <button
                  type="button"
                  className="btn btn-ghost btn-sm"
                  onClick={() => onRemove(p.id)}
                >
                  Remove
                </button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Price</td>
            {products.map((p) => (
              <td
                key={p.id}
                className={
                  new Set(products.map((x) => x.price)).size > 1 ? 'diff-highlight' : ''
                }
              >
                {formatPrice(p.price)}
              </td>
            ))}
          </tr>
          <tr>
            <td>Brand</td>
            {products.map((p) => (
              <td
                key={p.id}
                className={
                  new Set(products.map((x) => x.brand)).size > 1 ? 'diff-highlight' : ''
                }
              >
                {p.brand}
              </td>
            ))}
          </tr>
          <tr>
            <td>Rating</td>
            {products.map((p) => (
              <td
                key={p.id}
                className={
                  new Set(products.map((x) => x.rating)).size > 1 ? 'diff-highlight' : ''
                }
              >
                {p.rating} ★
              </td>
            ))}
          </tr>
          <tr>
            <td>Category</td>
            {products.map((p) => (
              <td key={p.id}>{p.category}</td>
            ))}
          </tr>
          {specKeys.map((key) => (
            <tr key={key}>
              <td style={{ textTransform: 'capitalize' }}>{key}</td>
              {products.map((p) => (
                <td
                  key={p.id}
                  className={isDifferent(key) ? 'diff-highlight' : ''}
                >
                  {p.specifications?.[key] ?? '—'}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default memo(CompareTable);
