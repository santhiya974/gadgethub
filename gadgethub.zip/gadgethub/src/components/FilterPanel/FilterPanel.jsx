import { memo } from 'react';
import { categories } from '../../data/products';

function FilterPanel({
  category,
  setCategory,
  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice,
  sortBy,
  setSortBy,
  onReset,
}) {
  return (
    <aside className="filter-panel">
      <div className="filter-group">
        <label>Category</label>
        <div className="filter-chips">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              className={`chip ${category === cat ? 'active' : ''}`}
              onClick={() => setCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="filter-group">
        <label htmlFor="min-price">Min Price ($)</label>
        <input
          id="min-price"
          type="number"
          min="0"
          placeholder="0"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
        />
      </div>

      <div className="filter-group">
        <label htmlFor="max-price">Max Price ($)</label>
        <input
          id="max-price"
          type="number"
          min="0"
          placeholder="Any"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
        />
      </div>

      <div className="filter-group">
        <label htmlFor="sort-by">Sort By</label>
        <select
          id="sort-by"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="default">Default</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="rating">Highest Rated</option>
          <option value="name">Name A–Z</option>
        </select>
      </div>

      <button type="button" className="btn btn-outline" style={{ width: '100%' }} onClick={onReset}>
        Reset Filters
      </button>
    </aside>
  );
}

export default memo(FilterPanel);
