import { memo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useProductContext } from '../../context/ProductContext';
import { useToast } from '../../context/ToastContext';
import { formatPrice } from '../../utils/helpers';

function ProductCard({ product, showActions = true }) {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { addToCompare, compareList } = useProductContext();
  const { showToast } = useToast();

  const onSale = product.originalPrice && product.originalPrice > product.price;
  const inWishlist = isInWishlist(product.id);
  const inCompare = compareList.includes(product.id);

  const handleAddCart = useCallback(
    (e) => {
      e.preventDefault();
      addToCart(product.id);
      showToast(`${product.name} added to cart`, 'success');
    },
    [addToCart, product, showToast]
  );

  const handleWishlist = useCallback(
    (e) => {
      e.preventDefault();
      toggleWishlist(product.id);
      showToast(
        inWishlist ? 'Removed from wishlist' : 'Added to wishlist',
        'info'
      );
    },
    [toggleWishlist, product.id, inWishlist, showToast]
  );

  const handleCompare = useCallback(
    (e) => {
      e.preventDefault();
      if (inCompare) {
        showToast('Already in compare list', 'info');
        return;
      }
      if (compareList.length >= 4) {
        showToast('Compare list full (max 4)', 'error');
        return;
      }
      addToCompare(product.id);
      showToast('Added to compare', 'success');
    },
    [addToCompare, compareList, inCompare, product.id, showToast]
  );

  return (
    <article className="product-card">
      <div className="product-card-image">
        <Link to={`/products/${product.id}`}>
          <img src={product.image} alt={product.name} loading="lazy" />
        </Link>
        <div className="product-card-badges">
          {product.featured && <span className="tag">Featured</span>}
          {onSale && <span className="tag tag-sale">Sale</span>}
        </div>
        {showActions && (
          <div className="product-card-actions-overlay">
            <button
              type="button"
              className="btn btn-icon btn-outline"
              onClick={handleWishlist}
              aria-label={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
              title="Wishlist"
            >
              {inWishlist ? '❤️' : '🤍'}
            </button>
            <button
              type="button"
              className="btn btn-icon btn-outline"
              onClick={handleCompare}
              aria-label="Add to compare"
              title="Compare"
            >
              ⚖️
            </button>
          </div>
        )}
      </div>
      <div className="product-card-body">
        <span className="product-card-category">{product.category}</span>
        <h3 className="product-card-title">
          <Link to={`/products/${product.id}`}>{product.name}</Link>
        </h3>
        <div className="product-rating" aria-label={`Rating ${product.rating} out of 5`}>
          <span>{'★'.repeat(Math.round(product.rating))}</span>
          <span>{product.rating}</span>
        </div>
        <div className="product-card-price">
          <span className="price-current">{formatPrice(product.price)}</span>
          {onSale && (
            <span className="price-original">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>
        <div className="product-card-footer">
          <button type="button" className="btn btn-primary btn-sm" onClick={handleAddCart}>
            Add to Cart
          </button>
          <Link to={`/products/${product.id}`} className="btn btn-outline btn-sm">
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}

export default memo(ProductCard);
