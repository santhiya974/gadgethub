import { memo } from 'react';
import ProductCard from '../ProductCard/ProductCard';
import ProductCardSkeleton from '../Skeleton/ProductCardSkeleton';

function ProductGrid({ products, loading = false, skeletonCount = 8 }) {
  if (loading) {
    return (
      <div className="product-grid">
        {Array.from({ length: skeletonCount }).map((_, i) => (
          <ProductCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (!products?.length) {
    return (
      <div className="empty-state">
        <h3>No products found</h3>
        <p>Try adjusting your filters or search terms.</p>
      </div>
    );
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

export default memo(ProductGrid);
