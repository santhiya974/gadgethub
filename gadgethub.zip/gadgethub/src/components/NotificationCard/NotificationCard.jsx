import { memo } from 'react';
import { Link } from 'react-router-dom';
import { formatPrice } from '../../utils/helpers';

function NotificationCard({ notification, onRead }) {
  const savings =
    notification.oldPrice && notification.newPrice
      ? notification.oldPrice - notification.newPrice
      : 0;

  return (
    <article
      className={`notification-card ${notification.read ? '' : 'unread'}`}
      onClick={() => onRead(notification.id)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onRead(notification.id)}
    >
      <span className="notification-card-icon" aria-hidden="true">
        📉
      </span>
      <div style={{ flex: 1 }}>
        <p style={{ fontWeight: 600, marginBottom: '0.25rem' }}>
          {notification.productName}
        </p>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
          {notification.message}
        </p>
        {savings > 0 && (
          <p style={{ color: 'var(--success)', fontSize: '0.85rem', marginTop: '0.35rem' }}>
            You save {formatPrice(savings)}!
          </p>
        )}
        <Link
          to={`/products/${notification.productId}`}
          className="btn btn-ghost btn-sm"
          style={{ marginTop: '0.5rem' }}
          onClick={(e) => e.stopPropagation()}
        >
          View Product →
        </Link>
      </div>
      {!notification.read && (
        <span className="badge" style={{ alignSelf: 'flex-start' }}>
          New
        </span>
      )}
    </article>
  );
}

export default memo(NotificationCard);
