import { memo, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProductContext } from '../../context/ProductContext';

function SearchBar({ placeholder = 'Search gadgets...', className = '' }) {
  const [query, setQuery] = useState('');
  const [showRecent, setShowRecent] = useState(false);
  const navigate = useNavigate();
  const { recentSearches, addRecentSearch } = useProductContext();
  const wrapperRef = useRef(null);

  const handleSearch = useCallback(
    (searchQuery) => {
      const q = (searchQuery ?? query).trim();
      if (!q) return;
      addRecentSearch(q);
      setShowRecent(false);
      navigate(`/products?search=${encodeURIComponent(q)}`);
    },
    [query, addRecentSearch, navigate]
  );

  const onSubmit = (e) => {
    e.preventDefault();
    handleSearch();
  };

  return (
    <form
      className={`search-bar ${className}`}
      onSubmit={onSubmit}
      ref={wrapperRef}
      role="search"
    >
      <span className="search-icon" aria-hidden="true">
        🔍
      </span>
      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onFocus={() => setShowRecent(true)}
        onBlur={() => setTimeout(() => setShowRecent(false), 200)}
        placeholder={placeholder}
        aria-label="Search products"
      />
      {showRecent && recentSearches.length > 0 && (
        <ul className="recent-searches">
          {recentSearches.map((term) => (
            <li key={term}>
              <button type="button" onMouseDown={() => handleSearch(term)}>
                {term}
              </button>
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}

export default memo(SearchBar);
