import { memo } from 'react';
import { Link } from 'react-router-dom';
import { formatPrice } from '../../utils/helpers';

function RecommendationCard({ product, reason, score }) {
  return (
    <article className="recommendation-card">
      <img src={product.image} alt={product.name} />
      <div>
        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{reason}</p>
        <h4 style={{ margin: '0.25rem 0' }}>
          <Link to={`/products/${product.id}`}>{product.name}</Link>
        </h4>
        <p style={{ fontWeight: 700 }}>{formatPrice(product.price)}</p>
      </div>
      {score != null && (
        <span className="recommendation-score">Match {Math.round(score)}%</span>
      )}
    </article>
  );
}

export default memo(RecommendationCard);
