import { Routes, Route } from 'react-router-dom';
import Home from '../pages/Home/Home';
import Products from '../pages/Products/Products';
import ProductDetails from '../pages/ProductDetails/ProductDetails';
import Cart from '../pages/Cart/Cart';
import Wishlist from '../pages/Wishlist/Wishlist';
import Compare from '../pages/Compare/Compare';
import Recommendations from '../pages/Recommendations/Recommendations';
import Notifications from '../pages/Notifications/Notifications';
import RecentlyViewed from '../pages/RecentlyViewed/RecentlyViewed';
import About from '../pages/About/About';
import Contact from '../pages/Contact/Contact';
import CheckoutSuccess from '../pages/CheckoutSuccess/CheckoutSuccess';
import NotFound from '../pages/NotFound/NotFound';

/**
 * Application route configuration using React Router v6.
 */
export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/products" element={<Products />} />
      <Route path="/products/:id" element={<ProductDetails />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/wishlist" element={<Wishlist />} />
      <Route path="/compare" element={<Compare />} />
      <Route path="/recommendations" element={<Recommendations />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="/recently-viewed" element={<RecentlyViewed />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/checkout-success" element={<CheckoutSuccess />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
