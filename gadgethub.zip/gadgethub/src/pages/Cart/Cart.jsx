import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { formatPrice } from '../../utils/helpers';

export default function Cart() {
  const navigate = useNavigate();
  const {
    cartItems,
    subtotal,
    tax,
    total,
    updateQuantity,
    removeFromCart,
    clearCart,
  } = useCart();

  if (!cartItems.length) {
    return (
      <div className="page container">
        <h1 className="page-title">Your Cart</h1>
        <div className="empty-state">
          <h3>Your cart is empty</h3>
          <p>Add some amazing gadgets to get started.</p>
          <Link to="/products" className="btn btn-primary">
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <h1 className="page-title">Your Cart</h1>
        <p className="page-subtitle">{cartItems.length} item(s)</p>

        <div className="cart-layout">
          <div>
            {cartItems.map(({ product, quantity }) => (
              <div key={product.id} className="cart-item">
                <img src={product.image} alt={product.name} />
                <div style={{ flex: 1 }}>
                  <Link to={`/products/${product.id}`}>
                    <h3 style={{ marginBottom: '0.25rem' }}>{product.name}</h3>
                  </Link>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                    {product.brand} · {product.category}
                  </p>
                  <p style={{ fontWeight: 700, marginTop: '0.5rem' }}>
                    {formatPrice(product.price)}
                  </p>
                  <div className="qty-control" style={{ marginTop: '0.75rem', width: 'fit-content' }}>
                    <button
                      type="button"
                      onClick={() => updateQuantity(product.id, quantity - 1)}
                      aria-label="Decrease quantity"
                    >
                      −
                    </button>
                    <span style={{ minWidth: 24, textAlign: 'center' }}>{quantity}</span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(product.id, quantity + 1)}
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontWeight: 700 }}>
                    {formatPrice(product.price * quantity)}
                  </p>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    style={{ marginTop: '0.5rem' }}
                    onClick={() => removeFromCart(product.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            <button type="button" className="btn btn-ghost" onClick={clearCart}>
              Clear Cart
            </button>
          </div>

          <aside className="checkout-summary">
            <h3 style={{ marginBottom: '1rem' }}>Order Summary</h3>
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatPrice(subtotal)}</span>
            </div>
            <div className="summary-row">
              <span>Tax (8%)</span>
              <span>{formatPrice(tax)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping</span>
              <span style={{ color: 'var(--success)' }}>FREE</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>{formatPrice(total)}</span>
            </div>
            <button
              type="button"
              className="btn btn-primary"
              style={{ width: '100%', marginTop: '1rem' }}
              onClick={() => navigate('/checkout-success')}
            >
              Proceed to Checkout
            </button>
          </aside>
        </div>
      </div>
    </div>
  );
}
