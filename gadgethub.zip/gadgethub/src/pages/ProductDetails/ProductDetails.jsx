import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProducts } from '../../hooks/useProducts';
import { useRecentlyViewed } from '../../hooks/useRecentlyViewed';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useProductContext } from '../../context/ProductContext';
import { useToast } from '../../context/ToastContext';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import { formatPrice } from '../../utils/helpers';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getProductById, related } = useProducts();
  const { addRecentlyViewed } = useRecentlyViewed();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { addToCompare, compareList } = useProductContext();
  const { showToast } = useToast();

  const product = getProductById(id);
  const [activeImage, setActiveImage] = useState(0);
  const relatedProducts = related(id, 4);

  useEffect(() => {
    if (product) {
      addRecentlyViewed(product.id);
      setActiveImage(0);
    }
  }, [product, addRecentlyViewed]);

  if (!product) {
    return (
      <div className="page container">
        <div className="empty-state">
          <h3>Product not found</h3>
          <button type="button" className="btn btn-primary" onClick={() => navigate('/products')}>
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  const images = product.images?.length ? product.images : [product.image];
  const onSale = product.originalPrice && product.originalPrice > product.price;

  const handleAddCart = () => {
    addToCart(product.id);
    showToast('Added to cart', 'success');
  };

  const handleCompare = () => {
    if (compareList.includes(product.id)) {
      showToast('Already in compare', 'info');
      return;
    }
    if (compareList.length >= 4) {
      showToast('Compare list full', 'error');
      return;
    }
    addToCompare(product.id);
    showToast('Added to compare', 'success');
  };

  return (
    <div className="page">
      <div className="container">
        <div className="product-details-grid">
          <div>
            <div className="gallery-main">
              <img src={images[activeImage]} alt={product.name} />
            </div>
            {images.length > 1 && (
              <div className="gallery-thumbs">
                {images.map((img, i) => (
                  <button
                    key={i}
                    type="button"
                    className={i === activeImage ? 'active' : ''}
                    onClick={() => setActiveImage(i)}
                  >
                    <img src={img} alt="" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <span className="product-card-category">{product.category}</span>
            <h1 className="page-title" style={{ marginTop: '0.25rem' }}>
              {product.name}
            </h1>
            <p style={{ color: 'var(--text-muted)', marginBottom: '0.5rem' }}>
              {product.brand}
            </p>
            <div className="product-rating" style={{ fontSize: '1rem', marginBottom: '1rem' }}>
              <span>{'★'.repeat(Math.round(product.rating))}</span>
              <span>{product.rating} / 5</span>
            </div>
            <div className="product-card-price" style={{ marginBottom: '1.5rem' }}>
              <span className="price-current" style={{ fontSize: '1.75rem' }}>
                {formatPrice(product.price)}
              </span>
              {onSale && (
                <span className="price-original" style={{ fontSize: '1.1rem' }}>
                  {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>
            <p style={{ marginBottom: '1.5rem', lineHeight: 1.7 }}>{product.description}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem' }}>
              <button type="button" className="btn btn-primary" onClick={handleAddCart}>
                Add to Cart
              </button>
              <button type="button" className="btn btn-outline" onClick={handleCompare}>
                Add to Compare
              </button>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => {
                  toggleWishlist(product.id);
                  showToast(
                    isInWishlist(product.id) ? 'Removed from wishlist' : 'Added to wishlist',
                    'info'
                  );
                }}
              >
                {isInWishlist(product.id) ? '♥ In Wishlist' : '♡ Add to Wishlist'}
              </button>
            </div>

            <h3 style={{ marginTop: '2rem', marginBottom: '0.75rem' }}>Specifications</h3>
            <table className="spec-table">
              <tbody>
                {Object.entries(product.specifications || {}).map(([key, value]) => (
                  <tr key={key}>
                    <th style={{ textTransform: 'capitalize' }}>{key}</th>
                    <td>{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {relatedProducts.length > 0 && (
          <section className="section">
            <h2 className="section-title">Related Products</h2>
            <ProductGrid products={relatedProducts} />
          </section>
        )}
      </div>
    </div>
  );
}
