import { useState, useMemo, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useProducts } from '../../hooks/useProducts';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import FilterPanel from '../../components/FilterPanel/FilterPanel';
import SearchBar from '../../components/SearchBar/SearchBar';
import Pagination from '../../components/Pagination/Pagination';

const ITEMS_PER_PAGE = 8;

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [category, setCategory] = useState(searchParams.get('category') || 'All');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sortBy, setSortBy] = useState('default');
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [page, setPage] = useState(1);

  useEffect(() => {
    const cat = searchParams.get('category');
    const q = searchParams.get('search');
    if (cat) setCategory(cat);
    if (q) setSearch(q);
  }, [searchParams]);

  const filters = useMemo(
    () => ({ category, minPrice, maxPrice, sortBy, search }),
    [category, minPrice, maxPrice, sortBy, search]
  );

  const { filtered, loading } = useProducts(filters);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE) || 1;
  const paginated = useMemo(() => {
    const start = (page - 1) * ITEMS_PER_PAGE;
    return filtered.slice(start, start + ITEMS_PER_PAGE);
  }, [filtered, page]);

  useEffect(() => {
    setPage(1);
  }, [category, minPrice, maxPrice, sortBy, search]);

  const resetFilters = useCallback(() => {
    setCategory('All');
    setMinPrice('');
    setMaxPrice('');
    setSortBy('default');
    setSearch('');
    setSearchParams({});
    setPage(1);
  }, [setSearchParams]);

  return (
    <div className="page">
      <div className="container">
        <h1 className="page-title">All Products</h1>
        <p className="page-subtitle">
          {filtered.length} product{filtered.length !== 1 ? 's' : ''} found
        </p>

        <div className="products-toolbar">
          <SearchBar placeholder="Filter by name, brand..." />
        </div>

        <div className="products-layout">
          <FilterPanel
            category={category}
            setCategory={setCategory}
            minPrice={minPrice}
            setMinPrice={setMinPrice}
            maxPrice={maxPrice}
            setMaxPrice={setMaxPrice}
            sortBy={sortBy}
            setSortBy={setSortBy}
            onReset={resetFilters}
          />
          <div>
            <ProductGrid products={paginated} loading={loading} />
            <Pagination
              currentPage={page}
              totalPages={totalPages}
              onPageChange={setPage}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
