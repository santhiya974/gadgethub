import { Link } from 'react-router-dom';
import { useRecentlyViewed } from '../../hooks/useRecentlyViewed';
import ProductGrid from '../../components/ProductGrid/ProductGrid';

export default function RecentlyViewed() {
  const { recentlyViewedProducts } = useRecentlyViewed();

  return (
    <div className="page">
      <div className="container">
        <h1 className="page-title">Recently Viewed</h1>
        <p className="page-subtitle">
          Your browsing history (stored in localStorage, latest first)
        </p>

        {recentlyViewedProducts.length === 0 ? (
          <div className="empty-state">
            <h3>No history yet</h3>
            <p>Products you view will appear here automatically.</p>
            <Link to="/products" className="btn btn-primary">
              Browse Products
            </Link>
          </div>
        ) : (
          <ProductGrid products={recentlyViewedProducts} />
        )}
      </div>
    </div>
  );
}
