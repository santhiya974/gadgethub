import { useProductContext } from '../../context/ProductContext';
import CompareTable from '../../components/CompareTable/CompareTable';

export default function Compare() {
  const { compareProducts, removeFromCompare, clearCompare } = useProductContext();

  return (
    <div className="page">
      <div className="container">
        <div className="section-header">
          <div>
            <h1 className="page-title">Compare Products</h1>
            <p className="page-subtitle" style={{ marginBottom: 0 }}>
              Side-by-side comparison (max 4 products). Differences are highlighted.
            </p>
          </div>
          {compareProducts.length > 0 && (
            <button type="button" className="btn btn-outline" onClick={clearCompare}>
              Clear All
            </button>
          )}
        </div>
        <CompareTable products={compareProducts} onRemove={removeFromCompare} />
      </div>
    </div>
  );
}
