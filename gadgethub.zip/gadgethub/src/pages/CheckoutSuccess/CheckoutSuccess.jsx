import { Link } from 'react-router-dom';
import { useEffect, useRef } from 'react';
import { useCart } from '../../context/CartContext';
import { formatPrice } from '../../utils/helpers';

export default function CheckoutSuccess() {
  const { clearCart, total } = useCart();
  const orderTotal = useRef(total);

  useEffect(() => {
    orderTotal.current = total;
    clearCart();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="page container">
      <div className="empty-state" style={{ maxWidth: 480, margin: '0 auto' }}>
        <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>✅</div>
        <h1 className="page-title">Order Placed!</h1>
        <p className="page-subtitle" style={{ marginBottom: '1.5rem' }}>
          Thank you for shopping at GadgetHub. Your order has been confirmed.
          {orderTotal.current > 0 &&
            ` Total charged: ${formatPrice(orderTotal.current)}`}
        </p>
        <div
          style={{
            display: 'flex',
            gap: '0.75rem',
            justifyContent: 'center',
            flexWrap: 'wrap',
          }}
        >
          <Link to="/products" className="btn btn-primary">
            Continue Shopping
          </Link>
          <Link to="/recommendations" className="btn btn-outline">
            View Recommendations
          </Link>
        </div>
      </div>
    </div>
  );
}
