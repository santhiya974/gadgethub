export default function About() {
  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 720 }}>
        <h1 className="page-title">About GadgetHub</h1>
        <p className="page-subtitle">
          Your trusted destination for premium tech gadgets since 2024.
        </p>

        <div
          style={{
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-lg)',
            padding: '2rem',
            lineHeight: 1.8,
          }}
        >
          <p style={{ marginBottom: '1rem' }}>
            <strong>GadgetHub</strong> is a modern e-commerce experience built entirely
            with React. We curate the latest smartphones, laptops, wearables, gaming gear,
            and smart home devices from industry-leading brands.
          </p>
          <p style={{ marginBottom: '1rem' }}>
            Our platform uses <strong>localStorage as a local database</strong> — no backend
            required. Your cart, wishlist, compare list, notifications, and browsing history
            persist across sessions in your browser.
          </p>
          <h3 style={{ margin: '1.5rem 0 0.75rem' }}>Our Mission</h3>
          <p style={{ marginBottom: '1rem' }}>
            To make cutting-edge technology accessible with smart recommendations,
            transparent pricing, and a seamless shopping experience on any device.
          </p>
          <h3 style={{ margin: '1.5rem 0 0.75rem' }}>Why Choose Us</h3>
          <ul style={{ paddingLeft: '1.25rem', color: 'var(--text-muted)' }}>
            <li style={{ marginBottom: '0.5rem', listStyle: 'disc' }}>Curated premium product catalog</li>
            <li style={{ marginBottom: '0.5rem', listStyle: 'disc' }}>AI-powered product recommendations</li>
            <li style={{ marginBottom: '0.5rem', listStyle: 'disc' }}>Price drop notifications</li>
            <li style={{ marginBottom: '0.5rem', listStyle: 'disc' }}>Side-by-side product comparison</li>
            <li style={{ listStyle: 'disc' }}>Fully responsive, dark mode ready</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
