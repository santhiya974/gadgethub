import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useProductContext } from '../../context/ProductContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { getRecommendations } from '../../utils/recommendations';
import RecommendationCard from '../../components/RecommendationCard/RecommendationCard';
import ProductGrid from '../../components/ProductGrid/ProductGrid';

export default function Recommendations() {
  const { products, recentlyViewed, loading } = useProductContext();
  const { cart } = useCart();
  const { wishlist } = useWishlist();

  const recommended = useMemo(
    () =>
      getRecommendations({
        products,
        cartIds: cart.map((i) => i.productId),
        wishlistIds: wishlist,
        recentlyViewedIds: recentlyViewed,
        limit: 8,
      }),
    [products, cart, wishlist, recentlyViewed]
  );

  const reasons = useMemo(() => {
    const viewed = recentlyViewed.slice(0, 2);
    const viewedCats = viewed
      .map((id) => products.find((p) => p.id === id)?.category)
      .filter(Boolean);
    return recommended.map((p) => {
      if (viewedCats.includes(p.category))
        return `Based on your recent ${p.category} views`;
      if (wishlist.some((id) => products.find((x) => x.id === id)?.category === p.category))
        return 'Matches your wishlist interests';
      if (
        cart.some(
          (item) =>
            products.find((x) => x.id === item.productId)?.category === p.category
        )
      )
        return 'Similar to items in your cart';
      return 'Top rated in our catalog';
    });
  }, [recommended, recentlyViewed, wishlist, cart, products]);

  return (
    <div className="page">
      <div className="container">
        <h1 className="page-title">AI Recommendations</h1>
        <p className="page-subtitle">
          Personalized picks based on your cart, wishlist, recently viewed items, and categories.
        </p>

        {recommended.length === 0 ? (
          <div className="empty-state">
            <h3>Not enough data yet</h3>
            <p>Browse products, add to cart or wishlist to get personalized recommendations.</p>
            <Link to="/products" className="btn btn-primary">
              Start Shopping
            </Link>
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '2rem' }}>
              {recommended.map((product, i) => (
                <RecommendationCard
                  key={product.id}
                  product={product}
                  reason={reasons[i]}
                  score={85 - i * 5}
                />
              ))}
            </div>
            <h2 className="section-title">You might also like</h2>
            <ProductGrid products={recommended} loading={loading} />
          </>
        )}
      </div>
    </div>
  );
}
