import { Link } from 'react-router-dom';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';
import { useToast } from '../../context/ToastContext';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import { formatPrice } from '../../utils/helpers';

export default function Wishlist() {
  const { wishlistProducts, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { showToast } = useToast();

  const moveToCart = (productId, name) => {
    addToCart(productId);
    removeFromWishlist(productId);
    showToast(`${name} moved to cart`, 'success');
  };

  if (!wishlistProducts.length) {
    return (
      <div className="page container">
        <h1 className="page-title">Wishlist</h1>
        <div className="empty-state">
          <h3>No favorites yet</h3>
          <p>Save products you love and move them to cart anytime.</p>
          <Link to="/products" className="btn btn-primary">
            Explore Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <h1 className="page-title">Wishlist</h1>
        <p className="page-subtitle">{wishlistProducts.length} saved item(s)</p>

        <div className="product-grid">
          {wishlistProducts.map((product) => (
            <article key={product.id} className="product-card">
              <div className="product-card-image">
                <Link to={`/products/${product.id}`}>
                  <img src={product.image} alt={product.name} />
                </Link>
              </div>
              <div className="product-card-body">
                <h3 className="product-card-title">
                  <Link to={`/products/${product.id}`}>{product.name}</Link>
                </h3>
                <p className="price-current">{formatPrice(product.price)}</p>
                <div className="product-card-footer">
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={() => moveToCart(product.id, product.name)}
                  >
                    Move to Cart
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm"
                    onClick={() => {
                      removeFromWishlist(product.id);
                      showToast('Removed from wishlist', 'info');
                    }}
                  >
                    Remove
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
