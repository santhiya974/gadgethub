import { useProductContext } from '../../context/ProductContext';
import NotificationCard from '../../components/NotificationCard/NotificationCard';

export default function Notifications() {
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    unreadCount,
  } = useProductContext();

  return (
    <div className="page">
      <div className="container">
        <div className="section-header">
          <div>
            <h1 className="page-title">Notifications</h1>
            <p className="page-subtitle" style={{ marginBottom: 0 }}>
              Simulated price drop alerts stored in localStorage
              {unreadCount > 0 && ` · ${unreadCount} unread`}
            </p>
          </div>
          {notifications.length > 0 && (
            <button
              type="button"
              className="btn btn-outline"
              onClick={markAllNotificationsRead}
            >
              Mark all read
            </button>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="empty-state">
            <h3>No notifications</h3>
            <p>Price drop alerts will appear here when deals are available.</p>
          </div>
        ) : (
          notifications.map((n) => (
            <NotificationCard
              key={n.id}
              notification={n}
              onRead={markNotificationRead}
            />
          ))
        )}
      </div>
    </div>
  );
}
