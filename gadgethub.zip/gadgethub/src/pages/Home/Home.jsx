import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useProducts } from '../../hooks/useProducts';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import SearchBar from '../../components/SearchBar/SearchBar';
import { categories } from '../../data/products';

const categoryIcons = {
  Mobile: '📱',
  Laptop: '💻',
  Audio: '🎧',
  Wearable: '⌚',
  Tablet: '📲',
  Gaming: '🎮',
  Camera: '📷',
  'Smart Home': '🏠',
  Accessories: '🖱️',
};

export default function Home() {
  const navigate = useNavigate();
  const { featured, products, loading } = useProducts();
  const recommended = useMemo(
    () => products.filter((p) => p.rating >= 4.7).slice(0, 4),
    [products]
  );

  const displayCategories = categories.filter((c) => c !== 'All').slice(0, 8);

  return (
    <>
      <section className="section">
        <div className="container">
          <div className="hero">
            <div className="hero-content">
              <h1>Discover the Future of Tech</h1>
              <p>
                Shop premium gadgets from top brands. Smart recommendations,
                price drop alerts, and seamless shopping — all in your browser.
              </p>
              <Link to="/products" className="btn btn-primary">
                Shop Now →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div style={{ maxWidth: 560, margin: '0 auto 2rem' }}>
            <SearchBar placeholder="Search phones, laptops, gaming gear..." />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Shop by Category</h2>
            <Link to="/products" className="btn btn-ghost">
              View All →
            </Link>
          </div>
          <div className="category-grid">
            {displayCategories.map((cat) => (
              <button
                key={cat}
                type="button"
                className="category-card"
                onClick={() => navigate(`/products?category=${encodeURIComponent(cat)}`)}
              >
                <div className="category-icon">{categoryIcons[cat] || '📦'}</div>
                <strong>{cat}</strong>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Featured Products</h2>
            <Link to="/products" className="btn btn-ghost">
              See All →
            </Link>
          </div>
          <ProductGrid products={featured} loading={loading} skeletonCount={4} />
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Recommended Gadgets</h2>
            <Link to="/recommendations" className="btn btn-ghost">
              AI Picks →
            </Link>
          </div>
          <ProductGrid products={recommended} loading={loading} skeletonCount={4} />
        </div>
      </section>
    </>
  );
}
