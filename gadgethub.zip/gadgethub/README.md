# GadgetHub — Tech Gadgets E-Commerce

A modern, full-featured React e-commerce demo using **React Router**, **Context API**, **custom hooks**, and **localStorage** as the database (no backend).

## Tech Stack

- React 18 + Vite
- React Router DOM v6
- Context API (`useState`, `useReducer`, `useEffect`, `useContext`, `useMemo`, `useCallback`, `React.memo`)
- Custom hooks: `useLocalStorage`, `useProducts`, `useRecentlyViewed`
- CSS3 responsive design with dark/light theme

## Features

- Product search, filter, sort, pagination
- Cart, wishlist, compare (max 4)
- Recently viewed products
- AI-style recommendation engine
- Price drop notifications (localStorage)
- Toast notifications, skeleton loading, checkout success page
- Recently searched products

## Routes

| Path | Page |
|------|------|
| `/` | Home |
| `/products` | Products listing |
| `/products/:id` | Product details |
| `/cart` | Shopping cart |
| `/wishlist` | Wishlist |
| `/compare` | Compare products |
| `/recommendations` | AI recommendations |
| `/notifications` | Price drop alerts |
| `/recently-viewed` | Browsing history |
| `/about` | About |
| `/contact` | Contact form |
| `*` | 404 |

## Local Storage Keys

- `gadgethub_products`
- `gadgethub_cart`
- `gadgethub_wishlist`
- `gadgethub_compare`
- `gadgethub_notifications`
- `gadgethub_recentlyViewed`
- `gadgethub_recentSearches`
- `gadgethub_theme`

## Getting Started

```bash
cd gadgethub
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

```bash
npm run build
npm run preview
```

## Project Structure

```
src/
├── components/     # Navbar, Footer, ProductCard, etc.
├── pages/          # Route pages
├── context/        # Cart, Wishlist, Product, Theme, Toast
├── hooks/          # useLocalStorage, useProducts, useRecentlyViewed
├── data/           # products.js seed data
├── routes/         # AppRoutes.js
├── styles/         # CSS variables, global, components
└── utils/          # helpers, recommendations, storage keys
```

## License

MIT — educational demo project.
